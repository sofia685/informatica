let suma = 0
let i = 3

while (i <= 10000){
  suma = suma + i
  i = i + 3
}
console.log(suma)
