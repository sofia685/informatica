let suma = 0
let i = 0

while (i <= 10000){
    suma = suma + i
     if(i % 3 == 0 || i % 5 == 0) {
 }
  i = i + 1
}
console.log(suma)