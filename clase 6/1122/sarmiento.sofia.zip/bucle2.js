let suma = 0
let i = 5

while (i <= 10000){
  suma = suma + i
  i = i + 5
}
console.log(suma)
